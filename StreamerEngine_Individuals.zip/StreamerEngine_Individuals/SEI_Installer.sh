#!${un}/${pw}bin${un}/${pw}bash
clear
echo #********************************************************************************************#
echo #********************************************************************************************#
echo #**                                                                                        **#
echo #**   This utility Installs SEI or Streamer Engine Libraries                               **#
echo #**   This utility Should expects to be invoked from Oracle Server                         **#
echo #**                                                                                        **#
echo #********************************************************************************************#
echo #********************************************************************************************#
read -p "Enter Username: " un
read -p "Enter Password: " pw
read -p "Enter Connect String: " cn
curr_path=$(dirname $(readlink -m $BASH_SOURCE))  

mkdir ${dd}

cd ${dd}


mkdir AnyDB2AnyDB_withBLOB_StreamerApp_C
chmod 755 AnyDB2AnyDB_withBLOB_StreamerApp_C
cd AnyDB2AnyDB_withBLOB_StreamerApp_C

CDE=expr`pwd`
cp ${curr_path}/AnyDB2AnyDB_withBLOB_StreamerApp_C $CDE

cd ..

mkdir AnyDB2AnyDB_withBLOB_StreamerApp_perl
chmod 755 AnyDB2AnyDB_withBLOB_StreamerApp_perl
cd AnyDB2AnyDB_withBLOB_StreamerApp_perl

CDE=expr`pwd`
cp ${curr_path}/AnyDB2AnyDB_withBLOB_StreamerApp_perl $CDE


echo ^#!${un}/${pw}bin${un}/${pw}bash > ${un}_UnInstaller.sh
echo rm -f  ${CDE} >> ${un}_UnInstaller.bat
echo rm -f ${un}_UnInstaller.sh >> ${un}_UnInstaller.sh

done
