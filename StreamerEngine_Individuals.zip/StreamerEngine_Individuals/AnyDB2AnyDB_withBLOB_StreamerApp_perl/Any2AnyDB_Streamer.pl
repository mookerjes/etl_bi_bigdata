#Invokation mechanism from Batch file
#
#Any2AnyDB.bat "Driver={Microsoft Access Driver (*.mdb, *.accdb)};dbq=" "SELECT * FROM CCONSOL_SH_ONLINE_MEDIA" "" "" F:\BITL_Framework_Alpha1_Release_01_14_2018\02_12_2018\VIRT\BITL_Framework\Test_Cases\temp1.accdb
#
#For Oracle invokation
#Any2AnyDB.bat "Driver=Oracle in XE;dbq=XE" "SELECT * FROM COTS_DM_METADATA_TAB" BITL_REPO BITL_REPO

use strict;
#use warnings;
use DBI;

my ($sec,$min,$hr,$mday,$mon,$year) = localtime(time);


# change $out_file to whatever path/name you want
#my $out_file = "results-$year-$mon-$mday-$hr.$min.$sec-output.csv";
#open OUT, '>', $out_file or die "could not write $out_file: $!";
# lookup the DBD::Oracle docs for the correct connection string


my $numArgs = $#ARGV + 1;
print "thanks, you gave me $numArgs command-line arguments.\n";

foreach my $argnum (0 .. $#ARGV) {

   print "$ARGV[$argnum]\n";

}
my $db_user   = $ARGV[2];
	my $db_passwd = $ARGV[3];
	my $db_file = $ARGV[4]; # Full path of Database File/DSN
	my $Driver = $ARGV[0];
   
	my $dbh = DBI->connect("dbi:ODBC:$Driver$db_file",$db_user,$db_passwd);
	

my $sql = $ARGV[1];

my $sth = $dbh->prepare($sql);
$sth->{'LongTruncOk'} = 1;
	$sth->{'LongReadLen'} = 20 *1024 *1024;
$sth->execute;
while (my $row = $sth->fetchrow_arrayref) {
    print join(',', map { s{"}{""}g; "\"$_\""; } @$row), "\n";
}
$sth->finish;
$dbh->disconnect;